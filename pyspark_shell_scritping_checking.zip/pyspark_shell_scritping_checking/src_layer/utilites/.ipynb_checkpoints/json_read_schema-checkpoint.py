
import json
from src.utilites.metadata import *
import os

print(os.curdir)
class json_read_schema():

    def meta_schema_read(self):
        """
        this method is to check the source path of the code.
        """
        with open("metadata//students_schema_check.json") as f:
            f_data=json.load(f)

            return(f_data["source_input_path"])
            source_input_path=f_data["source_input_path"]

js=json_read_schema()
js.meta_schema_read()