from utilites import json_read_schema, utility_reader,data_transformations
import logging
from pyspark.sql import DataFrame

import os

logging.info(os.curdir)
logging.info(os.path)
logging.info(os.walk)

#os.environ['SPARK_HOME'] = "C:/Bigdata/Spark3x"
#os.environ['PYTHONPATH'] = "C:/Bigdata/Spark3x/python/lib/py4j-0.10.9.5-src.zip"



spark_home = os.environ.get('SPARK_HOME')
print(spark_home)


class etl_main:
    if __name__ == "__main__":

        def dataframe_read(self: DataFrame) -> DataFrame:
            """
            :return:
             this method is to determine the dataframe reading functionality
            """
            df = aa.Spark_session().read.option("inferSchema", True).option("Header",True).csv(a.meta_schema_read()["etl_source_input_path"])
            return(df)


logging.info("src main class")
# reading json_read_schema class
a = json_read_schema.Json_read_schema()
logging.info(a.meta_schema_read())
logging.info(a.meta_schema_read()["etl_target_location_path"])

#sorting columns
logging.info(a.meta_schema_read()["sorting_columns"])




# reading utility class
aa = utility_reader.Utiltiy_reader()

# transformations class

a_trans= data_transformations.data_transformations()


#calling main function
b = etl_main()


#b.dataframe_read().show()

#a_trans.Xermations_sorting("age","salary",dataframe=b.dataframe_read()).show()
a_trans.Xermations_sorting(a.meta_schema_read()["sorting_columns"],dataframe=b.dataframe_read()).show()

print(a_trans.single_row_dataframe(dataframe_list=b.dataframe_read()))

print("***************** Writing to target location *********************")
b.dataframe_read().write.mode("overwrite").option("header", "true").csv(a.meta_schema_read()["etl_target_location_path"])

