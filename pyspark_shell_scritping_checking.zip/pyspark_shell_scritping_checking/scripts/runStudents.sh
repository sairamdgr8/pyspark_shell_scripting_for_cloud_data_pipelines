#!/bin/bash
sh /mnt/c/Users/Hp\ X360/Python_Spark/pyspark_shell_scritping_checking/scripts/setup.sh

status=$?
if [ $status -ne 0 ]
then
  echo "******************setup script run failed******************"
  exit 1
else
  echo "******************setup script run successfully******************"
fi

spark-submit "/mnt/c/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/src_layer/src_main.py" --metaConfigFilename="/mnt/c/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/src_layer/metadata/students_schema.json"

status=$?
if [ $status -ne 0 ]
then
  echo "******************src_layer Students job failed******************"
  exit 1
else
  echo "******************src_layer Students job Successful******************"
fi

spark-submit "/mnt/c/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/etl_layer/etl_main.py" --metaConfigFilename="/mnt/c/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/etl_layer/metadata/students_etl_schema.json"

status=$?
if [ $status -ne 0 ]
then
  echo "******************etl_layer Students job failed******************"
  exit 1
else
  echo "******************etl_layer Students job Successful******************"
fi
