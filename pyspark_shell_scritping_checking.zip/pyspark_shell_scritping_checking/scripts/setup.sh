#!/bin/bash

# Update package list
sudo apt update

# Install Java
sudo apt install -y openjdk-8-jdk

# Set JAVA_HOME
echo 'export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64' >> ~/.bashrc
echo 'export PATH=$JAVA_HOME/bin:$PATH' >> ~/.bashrc
source ~/.bashrc

# Install Python
sudo apt install -y python3

# installing necessary libraries
pip install -r /mnt/c/Users/Hp\ X360/Python_Spark/pyspark_shell_scritping_checking/requirements.txt

# Install PySpark
pip install pyspark
